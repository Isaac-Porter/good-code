#include "vex.h"

extern double g_input;
extern double g_speed;
extern double g_target;
extern double g_target2;
extern bool shot;
extern double g_input3;

int graph();
int tgraph();
int fgraph();